# README for Ansible Role: easytravel-deploy-apache2-config

Deploys an easyTravel configuration in 'templates/easytravel-apache2.conf.j2' to Apache2.