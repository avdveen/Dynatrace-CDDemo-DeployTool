# README for Ansible Role: easytravel-cd-deploy-derby-data

Deploys data to the 'easyTravelBusiness' Derby database.

## Requirements

- A dump of the 'easyTravelBusiness' Derby database must be provided in 'files/db-derby-easyTravelBusiness.tar.gz'.
  See the file 'templates/db-derby-backup-easyTravelBusiness-db.ij.j2' on how to create it if the data file is missing.