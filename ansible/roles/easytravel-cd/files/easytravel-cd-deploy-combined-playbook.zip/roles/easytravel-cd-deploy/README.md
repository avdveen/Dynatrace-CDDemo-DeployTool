# README for Ansible Role: easytravel-cd-deploy

Deploys binary application artifacts, configuration and data into the easyTravel Continuous Delivery demo environment.